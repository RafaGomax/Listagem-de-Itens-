# modelo_banner
Modelo de banner para eventos
